﻿using System.Text.Json.Serialization;

namespace TaskManagerSustentacao.Dtos
{
    public class TaskDto
    {
        public int Id { get; set; }

        [JsonPropertyName("Título")]
        public string Title { get; set; } = string.Empty;

        [JsonPropertyName("Descrição")]
        public string? Description { get; set; }

        [JsonPropertyName("Data de Vencimento")]
        public DateTime DueDate { get; set; }

        [JsonPropertyName("Status")]
        public string Status { get; set; } = "Pendente";
    }
}
