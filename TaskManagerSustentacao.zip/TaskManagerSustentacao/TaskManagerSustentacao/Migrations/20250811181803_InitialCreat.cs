﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskManagerSustentacao.Migrations
{
    public partial class InitialCreat : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
