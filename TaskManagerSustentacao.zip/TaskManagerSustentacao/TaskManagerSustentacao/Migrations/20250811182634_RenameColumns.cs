﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskManagerSustentacao.Migrations
{
    public partial class RenameColumns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Title",
                table: "Tasks",
                newName: "Nome da tarefa");

            migrationBuilder.RenameColumn(
                name: "DueDate",
                table: "Tasks",
                newName: "DataVencimento");

            migrationBuilder.RenameColumn(
                name: "Description",
                table: "Tasks",
                newName: "Descricao");

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Tasks",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Nome da tarefa",
                table: "Tasks",
                newName: "Title");

            migrationBuilder.RenameColumn(
                name: "Descricao",
                table: "Tasks",
                newName: "Description");

            migrationBuilder.RenameColumn(
                name: "DataVencimento",
                table: "Tasks",
                newName: "DueDate");

            migrationBuilder.AlterColumn<int>(
                name: "Status",
                table: "Tasks",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");
        }
    }
}
