﻿using TaskManagerSustentacao.Models;
using TaskManagerSustentacao.Repositories;

namespace TaskManagerSustentacao.Services
{
    public class TaskService
    {
        private readonly TaskRepository _repo;
        public TaskService(TaskRepository repo)
        {
            _repo = repo;
        }

        public async Task<List<TaskItem>> GetAllAsync() =>
            await _repo.GetAllAsync();

        public async Task<TaskItem?> GetByIdAsync(int id) =>
            await _repo.GetByIdAsync(id);

        public async Task AddAsync(TaskItem task)
        {
            if (string.IsNullOrWhiteSpace(task.Title))
                throw new ArgumentException("Título é obrigatório");

            if (task.DueDate <= DateTime.Now)
                throw new ArgumentException("Data de vencimento deve ser no futuro");

            await _repo.AddAsync(task);
        }

        public async Task UpdateAsync(TaskItem task) =>
            await _repo.UpdateAsync(task);

        public async Task DeleteAsync(TaskItem task) =>
            await _repo.DeleteAsync(task);
    }
}
